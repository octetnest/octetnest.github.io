# openconnectutils

To build this package :

1. Go to the parent directory.
2. Execute dpkg-deb --build openconnectutils
3. The openconnectutils.deb file will be built

To install this package :

1. apt-get install -f ./openconnectutils.deb

